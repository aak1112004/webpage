const express = require('express');
const hbs = require('hbs');

const app = express();
const path = require('path');

// DB connection
require("./db/conn")
const register = require("./models/registers")

//Port no
const port = process.env.PORT || 3000;

//Public Static Path
const static_path = path.join(__dirname,"../public")
const templates_path = path.join(__dirname,"../templates/views")
const partials_path = path.join(__dirname,"../templates/partials")

app.use(express.json())
app.use(express.urlencoded({extended:false}))

app.use(express.static(static_path));
app.set('view engine','hbs')
app.set('views',templates_path)
hbs.registerPartials(partials_path)


//Routing
//Home Page
app.get('/',(req,res)=>{
    res.render('register')
});


//register post
app.post('/register', async (req,res)=>{
    try {
 
     const registerStudents = new register({
         firstname:req.body.firstname,
         password:req.body.password
     })
     const registered = await registerStudents.save()
     res.statusCode(201).render("index")
 
    } catch (error) {
     res.status(400).send(error)
    }
 });


// login get
app.get('/loginpage',(req,res)=>{
    res.render('loginpage')
});

// login post
app.post('/loginpage', async (req,res)=>{
    try {    
         const firstname=req.body.firstname
         const password=req.body.password

            // console.log(`${firstname}, ${password}`)

        const userfirstname= await register.findOne({firstname:firstname})

        if(userfirstname.password===password){
            res.status(201).render("index")
                console.log("done")
        }else{
            res.send("password is not matching")
        }
//          

    } catch (error) {
     res.status(400).send("invalid email")
    }
 });

//404 Error Page
app.get('*',(req,res)=>{
    res.render('404error')
});

//Listening to the port 
app.listen(port,()=>{
    console.log(`Listening to the port ${port}`)
});