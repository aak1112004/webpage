const mongoose= require("mongoose")

const studentSchema = new mongoose.Schema({
    firstname:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true,
        // unique:true
    }
})

// collection

const Register = new mongoose.model("register",studentSchema)

module.exports = Register;